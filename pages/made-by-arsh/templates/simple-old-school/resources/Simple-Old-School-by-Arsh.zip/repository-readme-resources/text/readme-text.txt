This reopsitory contains codes and resources of my offical website, arshsaxena.github.io.
Website may not function properply below 1366x768 resolution.

NOTE: If you are using my site as a template for your website, I would be glad if you add a link to the original site with my name in footer.

<<WEBSITE SCREENSHOT>>

Arsh's Official Website (arshsaxena.github.io) on an Apple Mac Pro running macOS Catalina 10.15.3
