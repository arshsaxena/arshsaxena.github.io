# arshsaxena.github.io
<p>This reopsitory contains codes and resources of my offical website, <a href="https://arshsaxena.github.io">arshsaxena.github.io</a>.
<br>
Website may not function properply below 1366x768 resolution.
<br><br>
<i><b>NOTE: </b>If you are using my site as a template for your website, I would be glad if you add a link to the original site with my name in footer.</i></p>
<img align="center" src="https://raw.githubusercontent.com/arshsaxena/arshsaxena.github.io/main/repository-readme-resources/imgs/website-screenshot-macos-catalina.PNG"><i>Arsh's Official Website (<a href="https://arshsaxena.github.io">arshsaxena.github.io</a>) on an Apple Mac Pro running macOS Catalina 10.15.3</i>